package viceCity.models;

import viceCity.models.BasePlayer;

public class MainPlayer extends BasePlayer {

    public MainPlayer() {
        super("Tommy Vercetti", 100);
    }
}
