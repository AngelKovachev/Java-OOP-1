package viceCity.models;

public class CivilPlayer extends BasePlayer {
    public CivilPlayer(String name) {
        super(name, 50);
    }
}
